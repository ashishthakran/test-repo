package com.rabobank.mapper;

import com.rabobank.domain.CustomerEntity;
import com.rabobank.model.Customer;
import org.springframework.stereotype.Component;

@Component
public class CustomerMapper {

    public CustomerEntity toDomain(Customer customer) {
        return CustomerEntity.builder()
            .id(customer.getId())
            .name(customer.getName())
            .email(customer.getEmail())
            .build();
    }

    public Customer toModel(CustomerEntity entity) {
        return Customer.builder()
            .id(entity.getId())
            .name(entity.getName())
            .email(entity.getEmail())
            .build();
    }
}
