package com.rabobank.mapper;

import com.rabobank.domain.BankAccountEntity;
import com.rabobank.model.BankAccount;
import org.springframework.stereotype.Component;

@Component
public class BankAccountMapper {

    public BankAccountEntity toDomain(BankAccount account) {
        return BankAccountEntity.builder()
            .id(account.getId())
            .customerId(account.getCustomerId())
            .balance(account.getBalance())
            .build();
    }

    public BankAccount toModel(BankAccountEntity entity) {
        return BankAccount.builder()
            .id(entity.getId())
            .customerId(entity.getCustomerId())
            .balance(entity.getBalance())
            .build();
    }
}
