package com.rabobank.mapper;

import com.rabobank.domain.CardEntity;
import com.rabobank.model.Card;
import org.springframework.stereotype.Component;

@Component
public class CardMapper {

    public CardEntity toDomain(Card card) {
        return CardEntity.builder()
            .id(card.getId())
            .accountId(card.getAccountId())
            .accountHolderName(card.getAccountHolderName())
            .cardType(card.getCardType())
            .cardNumber(card.getCardNumber())
            .expiryDate(card.getExpiryDate())
            .cvv(card.getCvv())
            .transactionChargePercentage(card.getTransactionChargePercentage())
            .build();
    }

    public Card toModel(CardEntity entity) {
        return Card.builder()
            .id(entity.getId())
            .accountId(entity.getAccountId())
            .accountHolderName(entity.getAccountHolderName())
            .cardType(entity.getCardType())
            .cardNumber(entity.getCardNumber())
            .expiryDate(entity.getExpiryDate())
            .cvv(entity.getCvv())
            .transactionChargePercentage(entity.getTransactionChargePercentage())
            .build();
    }
}
