package com.rabobank.service;

import java.math.BigInteger;

import com.rabobank.domain.CustomerEntity;
import com.rabobank.exceptions.CustomerNotFoundException;
import com.rabobank.mapper.CustomerMapper;
import com.rabobank.model.Customer;
import com.rabobank.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

@Service
@Validated
@RequiredArgsConstructor
public class CustomerService {

    private final CustomerMapper customerMapper;
    private final CustomerRepository customerRepository;

    @Transactional
    public Customer create(@NonNull final Customer customer) {
        CustomerEntity entity = customerMapper.toDomain(customer);
        customerRepository.save(entity);
        return customerMapper.toModel(entity);
    }

    @Transactional(readOnly = true)
    public Customer get(@NonNull final BigInteger customerId) {
        return customerRepository.findById(customerId)
            .map(customerMapper::toModel)
            .orElseThrow(() -> new CustomerNotFoundException("Customer not found"));
    }
}
