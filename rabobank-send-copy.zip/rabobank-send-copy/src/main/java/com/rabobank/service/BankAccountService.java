package com.rabobank.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;

import com.rabobank.domain.BankAccountEntity;
import com.rabobank.exceptions.BankAccountNotFoundException;
import com.rabobank.exceptions.InsufficientBalanceException;
import com.rabobank.mapper.BankAccountMapper;
import com.rabobank.model.BankAccount;
import com.rabobank.repository.BankAccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

@Service
@Validated
@RequiredArgsConstructor
public class BankAccountService {

    private final BankAccountMapper bankAccountMapper;
    private final BankAccountRepository bankAccountRepository;
    private final CustomerService customerService;

    @Transactional
    public BankAccount create(@NonNull final BigInteger customerId, @NonNull final BankAccount bankAccount) {
        customerService.get(customerId);
        bankAccount.setCustomerId(customerId)  ;
        BankAccountEntity entity = bankAccountMapper.toDomain(bankAccount);
        bankAccountRepository.save(entity);
        return bankAccountMapper.toModel(entity);
    }

    @Transactional(readOnly = true)
    public BankAccount get(@NonNull final BigInteger id) {
        return bankAccountRepository.findById(id)
            .map(bankAccountMapper::toModel)
            .orElseThrow(() -> new BankAccountNotFoundException("Bank account not found"));
    }

    @Transactional(readOnly = true)
    public List<BankAccount> getAllAccounts(@NonNull final BigInteger customerId) {
        customerService.get(customerId);
        return bankAccountRepository.findAllByCustomerIdOrderByBalanceDesc(customerId)
            .stream().map(bankAccountMapper::toModel)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BankAccount> getAllAccounts() {
        return bankAccountRepository.findAllOrderByBalanceDesc()
            .stream().map(bankAccountMapper::toModel)
            .collect(Collectors.toList());
    }

    @Transactional
    public void withdrawMoney(@NonNull final BigInteger customerId,
        @NonNull final BigInteger bankAccountId,
        @NonNull final BigInteger amount) {
        customerService.get(customerId);
        BankAccount bankAccount = get(bankAccountId);

        if(bankAccount.getBalance().longValue() < amount.longValue()) {
            throw new InsufficientBalanceException("Account doesn't have enough balance to withdraw");
        }
    }
}
