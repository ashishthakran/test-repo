package com.rabobank.service;

import java.math.BigInteger;

import javax.transaction.Transactional;

import com.rabobank.domain.CardEntity;
import com.rabobank.mapper.CardMapper;
import com.rabobank.model.BankAccount;
import com.rabobank.model.Card;
import com.rabobank.model.Customer;
import com.rabobank.repository.CardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Service
@Validated
@RequiredArgsConstructor
public class CardService {

    private final CardMapper cardMapper;
    private final CardRepository cardRepository;
    private final BankAccountService bankAccountService;
    private final CustomerService customerService;

    @Transactional
    public Card create(@NonNull final BigInteger bankAccountId, @NonNull Card card) {
        BankAccount bankAccount = bankAccountService.get(bankAccountId);
        Customer customer = customerService.get(bankAccount.getCustomerId());

        card.setAccountId(bankAccountId);
        card.setAccountHolderName(customer.getName());

        CardEntity entity = cardMapper.toDomain(card);
        cardRepository.save(entity);
        return cardMapper.toModel(entity);
    }
}
