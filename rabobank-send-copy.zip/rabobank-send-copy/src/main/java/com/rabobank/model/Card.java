package com.rabobank.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Instant;

import com.rabobank.enums.CardType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class Card implements Serializable {

    private BigInteger id;
    private BigInteger accountId;
    private String accountHolderName;
    private CardType cardType;
    private Long cardNumber;
    private Instant expiryDate;
    private Integer cvv;
    private BigDecimal transactionChargePercentage;
}
