package com.rabobank.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Table(name = "bank_account")
public class BankAccountEntity implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    private BigInteger id;

    @Column(name = "customer_id", nullable = false)
    private BigInteger customerId;

    @Column(name = "balance", nullable = false)
    private BigDecimal balance;
}
