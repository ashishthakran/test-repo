package com.rabobank.controller;

import java.math.BigInteger;
import java.util.List;

import com.rabobank.model.BankAccount;
import com.rabobank.service.BankAccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class BankAccountController {

    private final BankAccountService bankAccountService;

    @GetMapping(value = "/{customerId}/accounts", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<BankAccount>> getCustomerAccounts(@PathVariable(name = "customerId") @NonNull final BigInteger customerId) {
        return ResponseEntity.ok(bankAccountService.getAllAccounts(customerId));
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<BankAccount>> getAllAccounts() {
        return ResponseEntity.ok(bankAccountService.getAllAccounts());
    }

    @GetMapping(value = "/{customerId}/accounts/{accountId}/withdraw", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> withdrawMoney(@PathVariable(name = "customerId") @NonNull final BigInteger customerId,
        @PathVariable(name = "accountId") @NonNull final BigInteger accountId) {
        return null;//ResponseEntity.ok(bankAccountService.getAllAccounts());
    }
}
