package com.rabobank.enums;

public enum CardType {

    DEBIT,
    CREDIT;
}
