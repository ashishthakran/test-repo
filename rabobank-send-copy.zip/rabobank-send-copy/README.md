# 

## Run Spring Boot application
```
mvn spring-boot:run
```

