---
name: compact-validation-runner
description: Runs focused build, test, Git, Cucumber, Mockito, Gatling, and diagnostic commands while minimizing model context and log noise. Use after code changes, debugging, or when command output would otherwise consume excessive context.
compatibility: LM Studio Bionic coding project. Prefer RTK for supported commands if RTK is already installed; never install it automatically.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Compact Validation Runner

Prefer the narrowest validation that proves the change.

If RTK is already installed and supports a command, prefer RTK-wrapped noisy commands when semantics are unchanged.

Capture only:
- command and exit code;
- failed test names;
- compiler errors;
- first relevant/root stack trace;
- root cause;
- concise summary;
- success/failure counts.

Do not return thousands of successful-test lines, duplicated traces, dependency chatter, or progress output.

## Order

1. Compile affected module.
2. Run directly affected unit tests.
3. Run relevant Cucumber/integration tests.
4. Run project-standard static checks.
5. Run Gatling/performance checks only when justified.
6. Inspect Git diff.

Never hide failures due to compression. Never bypass company artifact configuration or download unapproved executables/scripts/images/packages.
