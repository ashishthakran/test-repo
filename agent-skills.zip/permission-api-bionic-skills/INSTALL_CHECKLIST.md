# Installation Checklist

- [ ] Bionic → Settings → Skills
- [ ] Add and review each SKILL.md
- [ ] Keep built-in Web Search OFF for confidential project work
- [ ] Keep Neo4j MCP read-only
- [ ] Confirm approved MCP servers only
- [ ] Keep corporate proxy/firewall/EDR/DLP active
- [ ] Do not grant broad auto-download/auto-execute permissions
- [ ] Explicitly test @security-boundary
- [ ] Test @context-budget on a harmless slice
- [ ] Test Neo4j schema-only reverse engineering
- [ ] Verify no Neo4j write tool is exposed
- [ ] Test project-brain persistence
- [ ] Then test implementation/review/translation skills
