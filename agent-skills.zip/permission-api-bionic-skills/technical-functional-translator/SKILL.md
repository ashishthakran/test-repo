---
name: technical-functional-translator
description: Converts verified technical knowledge plus functional source material into clear human-readable project/domain documentation without losing traceability. Use after technical reverse engineering/review for business-oriented mental models, onboarding material, functional flows, and stakeholder-readable explanations.
compatibility: Best used with Gemma or another strong local writing/reasoning model. Inputs must already be local/approved.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Technical to Functional Translator

Do not invent business meaning from code alone.

Use verified technical brain entries, reviewed Neo4j model, approved functional documents, business terminology, acceptance criteria, and verified tests.

Map:
business actor -> intent -> workflow -> rule -> endpoint/event -> implementation -> graph/data -> external integration -> tests.

Label conclusions:
- `FUNCTIONAL FACT`
- `TECHNICAL FACT`
- `INFERENCE`
- `UNKNOWN`
- `OPEN QUESTION`

If code and functional documentation disagree, show the conflict.

Use clear Markdown, tables where useful, and Mermaid for flows/relationships. Never modify production code as part of translation.

Do not use public web search to infer internal business behavior.
