---
name: document-evidence-ingestion
description: Extracts structured evidence-linked knowledge from local PDFs, PowerPoint/PDF exports, images, screenshots, text, and Confluence exports for the Permission API project brain. Use when ingesting functional, architecture, operational, or business documentation.
compatibility: Bionic project with local document/image support. Use only local/approved files; do not upload confidential files to cloud tools.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Document Evidence Ingestion

For each local document/image:

1. Identify title/type/version/date where available.
2. Extract only relevant information.
3. Preserve page/slide/section evidence where possible.
4. Separate explicit facts from interpretation.
5. Cross-link to existing brain concepts.
6. Record contradictions and unknowns.
7. Persist a compact local summary.

Extract terminology, actors, workflows, rules, APIs/events, graph/data concepts, systems/integrations, operational constraints, error flows, performance expectations, security rules, acceptance criteria, and open questions.

Use labels:
- `DOCUMENT-FACT`
- `DIAGRAM-FACT`
- `INFERENCE`
- `CONFLICT`
- `UNKNOWN`

Do not inject entire large documents into later prompts after extraction. Keep confidential files local and never install third-party parsers automatically.
