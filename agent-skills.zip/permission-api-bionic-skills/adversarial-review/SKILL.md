---
name: adversarial-review
description: Performs independent evidence-based review of code changes or reverse-engineered documentation. Use after implementation/analysis to find correctness, architecture, Neo4j, Kafka, test, performance, security, and maintainability gaps without trusting previous-model conclusions.
compatibility: Intended for GPT-OSS or another local reviewer model in Bionic. Repository access remains local.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Adversarial Review

Assume the implementation/documentation may be wrong.

Review requirement coverage, Java/Spring correctness, module boundaries, Neo4j/Cypher, transactions, Kafka behavior, retries/idempotency, concurrency, error handling, compatibility, security, Cucumber, Mockito, Gatling/performance, hot paths, configuration, shell utilities, pipelines, observability, complexity, unsupported APIs, and contradictions.

Every BLOCKER/HIGH finding must include evidence, file/symbol/query, why it matters, concrete correction, and confidence.

Severity:
- `BLOCKER`
- `HIGH`
- `MEDIUM`
- `LOW`
- `INFORMATIONAL`

Do not call style preference a defect. Verify material claims against repository/schema/tests.

No external transmission or public downloads.
