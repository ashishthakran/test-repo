---
name: project-brain-curator
description: Maintains a compact evidence-backed durable project brain shared across Bionic sessions. Use after reverse engineering, reviews, feature work, document ingestion, or Neo4j analysis to persist verified knowledge without bloating future contexts.
compatibility: Bionic Project with shared project files.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Project Brain Curator

Store facts, not conversation transcripts. Keep files small and topic-specific. Link concepts rather than duplicating them. Preserve evidence.

Recommended structure:

```text
.ai-local/brain/
  00-index.md
  system/
  modules/
  domain/
  endpoints/
  workflows/
  neo4j/
  kafka/
  export/
  tests/
  performance/
  configuration/
  utilities/
  pipelines/
  standards/
  terminology/
  traceability/
  decisions/
  unknowns/
```

Use confidence labels:
- `FACT-VERIFIED-CODE`
- `FACT-VERIFIED-DB`
- `FACT-VERIFIED-TEST`
- `FACT-VERIFIED-DOC`
- `INFERENCE`
- `ASSUMPTION`
- `UNKNOWN`
- `OPEN-QUESTION`

Before writing, search existing brain, update canonical entries, avoid duplicates, record conflicts, and retain evidence paths.

Future sessions should load only the index and relevant brain files, not the whole brain.

The brain is confidential and must never be sent externally.
