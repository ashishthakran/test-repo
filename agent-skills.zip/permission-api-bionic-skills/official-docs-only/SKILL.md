---
name: official-docs-only
description: Uses a strict official-vendor-only policy for public technical documentation. Use when current Spring Boot, Java/OpenJDK, Neo4j, Cucumber, Mockito, Gatling, Maven, Kafka, or Docker documentation is needed while project source must remain private.
compatibility: Intended for Bionic with built-in Web Search disabled unless explicitly authorized. This skill is behavioral policy, not a network firewall.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Official Documentation Only

## Initial Allowlist

- `docs.spring.io`
- `spring.io`
- `openjdk.org`
- `docs.oracle.com`
- `neo4j.com`
- `cucumber.io`
- `mockito.org`
- `gatling.io`
- `docs.gatling.io`
- `maven.apache.org`
- `repo.maven.apache.org`
- `central.sonatype.com`
- `kafka.apache.org`
- `docs.docker.com`

Do not add a domain without explicit user approval.

## Rules

1. Never perform general web search from confidential repository context.
2. Never include source code, internal class/package names, internal URLs, stack traces, database data, business identifiers, company terminology, or logs in an external request.
3. Formulate documentation requests with generic public technology terms only.
4. Never download scripts, binaries, installers, archives, packages, plugins, or Docker images.
5. Never execute retrieved content.
6. If an answer cannot be obtained from an approved official source, stop rather than using a third party.
7. Save useful summaries locally with source URL, product/version, retrieval date, and supported fact.
8. Keep retrieved content compact.
9. Distinguish `OFFICIAL-DOC FACT`, `PROJECT FACT`, `INFERENCE`, and `UNKNOWN`.

## Security Note

Hard enforcement must come from the fetch/MCP tool and corporate network controls, not this skill alone.
