---
name: code-slice-reverse-engineering
description: Reverse engineers a bounded slice of the Permission API codebase and produces evidence-linked technical documentation. Use for modules, endpoints, services, Kafka flows, utilities, configurations, pipelines, tests, or one business workflow without loading the whole repository.
compatibility: LM Studio Bionic coding project for Java/Spring Boot/Neo4j/Kafka/Cucumber/Mockito/Gatling repositories.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Code Slice Reverse Engineering

## Sequence

1. Define scope and explicit boundaries.
2. Search for likely entry points.
3. Identify relevant implementation files.
4. Read only required files.
5. Trace entry point, callers, downstream calls, services, persistence, configuration, external integrations, Kafka/event interactions, error handling, tests, and operational utilities.
6. Record evidence using file paths and symbols.
7. Persist a compact technical artifact.
8. Record unknowns instead of guessing.

## Output

```markdown
# <Slice Name>
## Scope
## Entry Points
## Components
## Control Flow
## Data Flow
## Configuration
## Neo4j Impact
## Kafka / External Integrations
## Tests
## Operational / Pipeline Impact
## Evidence
## Verified Facts
## Inferences
## Unknowns
## Questions for Reviewer
```

Every material technical claim must be traceable to source, configuration, query, test, pipeline, or local database/schema evidence.

Never send repository material externally or automatically download/execute public scripts/tools.
