# Permission API Bionic Skills Pack

## Recommended skills

1. security-boundary
2. context-budget
3. official-docs-only
4. code-slice-reverse-engineering
5. neo4j-readonly-reverse-engineering
6. implementation-engineer
7. compact-validation-runner
8. adversarial-review
9. project-brain-curator
10. technical-functional-translator
11. document-evidence-ingestion

## Install in Bionic

For each skill:

1. Open **Bionic → Settings → Skills**.
2. Add the local `SKILL.md`.
3. Review it before enabling.
4. Repeat for each skill you want available.

Bionic can invoke skills automatically when relevant, or you can explicitly invoke them with `@`.

## Recommended combinations

Reverse engineer code:
`@security-boundary @context-budget @code-slice-reverse-engineering`

Reverse engineer Neo4j:
`@security-boundary @context-budget @neo4j-readonly-reverse-engineering`

Implement:
`@security-boundary @context-budget @implementation-engineer @compact-validation-runner`

Review:
`@security-boundary @adversarial-review`

Update project brain:
`@security-boundary @project-brain-curator`

Translate technical to functional:
`@security-boundary @technical-functional-translator`

Ingest local documents:
`@security-boundary @document-evidence-ingestion @project-brain-curator`

Official documentation:
`@security-boundary @official-docs-only`

## Security Warning

Skills are instructions, not a firewall or DLP system. Keep hard controls in the MCP/tool configuration, Neo4j read-only account/configuration, company proxy/firewall/EDR/DLP, and package/artifact repository configuration.
