---
name: neo4j-readonly-reverse-engineering
description: Reverse engineers the local Neo4j graph safely using read-only MCP/schema queries and repository evidence. Use to discover labels, relationships, properties, indexes, constraints, query families, and mappings between code, Cypher, endpoints, workflows, and tests.
compatibility: Requires an already-configured official Neo4j MCP connected to the intended local database in read-only mode.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Neo4j Read-Only Reverse Engineering

## Absolute Rules

- Use read-only MCP operations only.
- Never create, merge, set, delete, drop, alter, or mutate data/schema.
- Never disable read-only mode.
- Never dump large datasets.
- Prefer schema metadata and aggregate counts over business records.
- Use `LIMIT` for representative examples.

## Order

1. Labels, relationship types, property keys, indexes, constraints.
2. Topology: source label, relationship, target label, direction, cardinality clues.
3. Representative bounded patterns.
4. Correlate to Java entities/mappers, repositories, Cypher, services, endpoints, Kafka/sync flows, Cucumber tests, Gatling paths.
5. Note performance relevance: hot endpoints, high-cardinality traversals, index evidence, repeated round trips.

## Output

```markdown
# Neo4j Graph Slice
## Labels
## Relationship Types
## Topology
## Properties
## Indexes and Constraints
## Representative Query Patterns
## Code Mapping
## Endpoint / Workflow Mapping
## Test Mapping
## Performance Notes
## Evidence
## Unknowns
```

Use confidence labels: `VERIFIED-SCHEMA`, `VERIFIED-CODE`, `VERIFIED-QUERY`, `INFERENCE`, `UNKNOWN`.

Never send graph structure, Cypher, schema, node data, or internal terminology externally.
