---
name: context-budget
description: Keeps local-model work within a constrained context budget by slicing repository analysis, limiting retrieved files and tool output, persisting durable knowledge to project files, and starting fresh sessions when appropriate. Use for large repositories, reverse engineering, long tasks, multi-file work, or context/latency problems.
compatibility: Designed for LM Studio Bionic with a local model using approximately a 32K-token context window.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Context Budget Manager

Treat the context window as temporary working memory, not project memory.

## Working Loop

1. Discover.
2. Select one bounded slice.
3. Read only relevant files.
4. Extract facts.
5. Persist compact findings to project-brain files.
6. Discard unnecessary detail.
7. Continue with the next slice.

Never ingest the entire repository, database, test suite, or documentation set into one session.

## Preferred Slice

Use one endpoint/family, business workflow, deployable module, service/repository path, Neo4j query family, Kafka flow, Cucumber feature family, Gatling scenario, utility group, or pipeline.

## Retrieval Rules

- Search before reading.
- Read the smallest necessary file set.
- Prefer paths and summaries over copied source.
- Do not repeatedly reload verified facts already persisted.
- Ignore build output, dependency caches, binaries, target/build folders, generated files, and database dumps unless directly relevant.

## Output Rules

- Never return entire Maven/Gradle/test logs by default.
- Keep root failure, relevant stack trace, failed-test names, compiler errors, and final summary.
- Save long raw output locally and search it selectively.
- Prefer RTK-wrapped noisy commands when RTK is already installed and supported.

## Session Discipline

Start a fresh session after a bounded investigation, when history becomes unrelated, when switching domain/module, or when context growth causes latency. Persist durable facts before ending.
