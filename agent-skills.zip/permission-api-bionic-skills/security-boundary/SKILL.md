---
name: security-boundary
description: Enforces strict corporate-data, network, download, execution, and privacy boundaries for all Permission API work. Use whenever a task involves company source code, internal documents, Neo4j, shell commands, external documentation, MCP tools, build tools, or internet/network access.
compatibility: Designed for LM Studio Bionic on a corporate laptop with local models and company-managed network controls.
metadata:
  version: "1.0"
  project: "permission-api"
---

# Security Boundary

Treat repository source, internal documents, Neo4j data, identifiers, URLs, stack traces, logs, schemas, package names, business terminology, credentials, customer information, and operational details as confidential.

## Mandatory Rules

1. Never transmit confidential project information to a public internet service.
2. Never include repository content or internal identifiers in a web query, URL, request body, analytics payload, or external tool call.
3. Public documentation retrieval is allowed only from explicitly approved official documentation domains.
4. Do not use general web search from a confidential project session unless the user explicitly authorizes it.
5. Never download and execute a shell script, executable, installer, archive, package, Docker image, binary, or plugin from the public internet without explicit user approval.
6. Never run `curl ... | sh`, `curl ... | bash`, `wget ... && ...`, or equivalent download-and-execute patterns.
7. If an external resource appears necessary, stop and report: name, exact version, official publisher, official URL, why it is needed, what it would execute/change, and whether a local alternative exists.
8. The user performs any approved external acquisition manually.
9. Never expose secrets such as passwords, tokens, API keys, cookies, certificates, `.env` contents, or credentials.
10. Prefer read-only operations during analysis and reverse engineering.
11. Keep Neo4j MCP read-only for reverse engineering.
12. Company artifact repositories may be used through existing company configuration; do not bypass company mirrors.
13. Do not modify company-managed proxy, EDR, certificates, VPN, endpoint security, or DLP settings.
14. If uncertain whether a network operation is allowed, stop and ask.

## Safe Failure

When a task cannot be completed under these restrictions, do not work around them. Explain what is blocked and what human action is required.
