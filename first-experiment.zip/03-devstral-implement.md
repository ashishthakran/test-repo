# 03 — Devstral: Implement and Run the Cucumber Integration Test

## YOU ONLY NEED TO FILL THIS IF NOT ALREADY CLEAR

```text
TARGET_FEATURE = <target .feature file path>
```

Required reviewed input:

```text
.ai-local/current-story/business-workflow.md
.ai-local/current-story/story-understanding.md
```

## MODEL

Run in **Devstral Small 2** after the user has approved `story-understanding.md`.

Apply:

```text
@security-boundary
@context-budget
@implementation-engineer
@compact-validation-runner
```

## TASK

Implement the approved integration-test scenario at `TARGET_FEATURE`.

Rules:

1. Follow existing Cucumber naming conventions.
2. Follow existing formatting and tags.
3. Reuse existing Given/When/Then statements wherever semantically correct.
4. Reuse existing step definitions.
5. Reuse existing test-data/setup patterns.
6. Make the smallest necessary change.
7. Do not refactor unrelated tests.
8. Do not change production code unless the story genuinely requires it and the user explicitly approves.
9. Do not weaken assertions merely to make the test pass.
10. Do not invent APIs, steps or behavior.
11. Neo4j remains READ ONLY except for whatever normal approved integration-test setup the existing test framework itself performs.

## VALIDATE

Run the narrowest relevant validation:

1. feature/test syntax and compilation;
2. new scenario;
3. directly related existing scenario(s) where practical;
4. inspect failure/root cause;
5. inspect Git diff.

Use already-installed RTK for supported noisy commands if appropriate. Install nothing.

If the test fails, diagnose from evidence. Do not randomly mutate the test until green.

## COMPLETION CRITERIA

```text
Cucumber syntax       PASS
Compilation           PASS
New scenario          PASS
Relevant regression   PASS
Unexpected changes    NONE
Unnecessary new steps NONE
Blocking UNKNOWNs     NONE
```

## OUTPUT

Create:

```text
.ai-local/current-story/implementation-summary.md
```

Include:

```markdown
# Implementation Summary

## Business Subflow
## Discovered Endpoint
## Existing Scenario Reused
## New/Changed Scenario
## Reused Steps
## New Step Definitions
## Relevant Neo4j Relationships
## Validation Results
## Files Changed
## Remaining Unknowns
```

Then tell the user the result and STOP.

## SECURITY

Keep all data local. Web Search OFF. No public downloads or execution. Never expose secrets.
