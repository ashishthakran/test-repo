# 01 — Gemma 4: Extract Business Workflow

## YOU ONLY NEED TO FILL THESE

```text
BASELINE_WORKFLOW_FILE = <path to baseline PPT/PDF/JPG/PNG>
NEW_USE_CASE_FILE      = <path to new-use-case PPT/PDF/JPG/PNG>
HIGHLIGHT_MEANING      = <example: green arrows represent the new subflow>
```

## MODEL

Run this prompt in a Bionic session using **Gemma 4 31B QAT**.

Apply:

```text
@security-boundary
@context-budget
```

## TASK

Analyze `BASELINE_WORKFLOW_FILE` and `NEW_USE_CASE_FILE`.

Extract and understand:

- all visible text;
- text inside PowerPoint shapes;
- text visible inside embedded images;
- actors/personas;
- boxes/shapes/nodes;
- groups/containers;
- arrows and lines;
- arrow direction;
- arrow color;
- labels attached to connectors;
- visible conditions;
- expected-result/status text.

Do not perform plain OCR only. Reconstruct how the visual objects are connected.

For every connector determine:

```text
SOURCE -> TARGET
direction
color
label
confidence
```

Use `HIGHLIGHT_MEANING` to isolate the new story subflow.

Determine:

1. complete visible baseline workflow;
2. highlighted new subflow;
3. where the new subflow starts;
4. ordered nodes and relationships;
5. where it differs from the baseline;
6. where it rejoins or terminates;
7. visible expected result;
8. ambiguous/unclear elements.

Do not infer Java code, API endpoints, Cucumber implementation or Neo4j implementation.

Label conclusions:

```text
VISUAL-FACT
TEXT-FACT
INFERENCE
UNKNOWN
```

Never invent a missing connection.

## OUTPUT

Create this file in the project:

```text
.ai-local/current-story/business-workflow.md
```

Use this structure:

```markdown
# Business Workflow

## Source Files

## Baseline Workflow

## Actors / Personas

## Nodes / Shapes

## Relationships
| Source | Relationship/Label | Target | Direction | Color | Confidence |

## Highlighted New Subflow

## Difference From Baseline

## Expected Result

## Unknown / Ambiguous Elements

## Evidence
```

At the end, verify that the output file exists.

Then STOP.

Tell the user:

```text
Gemma visual extraction is complete.
Review .ai-local/current-story/business-workflow.md.
If correct, load Devstral Small 2 and run 02-devstral-discovery.md.
```

## SECURITY

Keep all supplied files and extracted information local. Web Search OFF. Do not upload anything externally. Do not download or execute anything.
