# 02 — Devstral: Discover Existing Test → Endpoint → Code → Neo4j

## YOU ONLY NEED TO FILL THESE

```text
SIMILAR_FEATURE_1 = <path to existing similar .feature file>
SIMILAR_FEATURE_2 = <path to existing similar .feature file>
SIMILAR_FEATURE_3 = <optional path or NONE>

TARGET_FEATURE    = <path where the new feature/scenario should eventually be written>
```

Gemma's verified output must already exist:

```text
.ai-local/current-story/business-workflow.md
```

## MODEL

Run this prompt in a new Bionic session using **Devstral Small 2**.

Apply:

```text
@security-boundary
@context-budget
@code-slice-reverse-engineering
@neo4j-readonly-reverse-engineering
```

## TASK

Do NOT implement anything yet.

The supplied existing Cucumber tests are your technical starting points.

Do not ask the user for:

- endpoint;
- controller;
- Java classes;
- step-definition classes;
- services;
- repositories;
- Cypher queries;
- Neo4j nodes;
- Neo4j relationships.

Discover those yourself from repository and read-only Neo4j evidence.

### 1. Understand the existing Cucumber tests

Read:

```text
SIMILAR_FEATURE_1
SIMILAR_FEATURE_2
SIMILAR_FEATURE_3
```

Determine:

- naming and formatting conventions;
- tags;
- Background usage;
- Given/When/Then vocabulary;
- scenario/scenario-outline patterns;
- data tables/examples;
- test-data setup and cleanup;
- response assertions.

For relevant Gherkin statements, locate their existing Java step definitions and helpers.

Build a catalog of reusable existing steps.

### 2. Discover which endpoint the tests call

Trace from the supplied feature files:

```text
feature
-> step definition
-> helper/client
-> request construction
-> HTTP invocation
-> endpoint
```

Determine from evidence:

- HTTP method;
- endpoint path;
- request parameters/body;
- headers if relevant;
- test-data inputs.

Do not scan unrelated endpoints.

### 3. Reverse engineer the relevant production path

From the discovered endpoint trace:

```text
endpoint
-> controller/resource/handler
-> service
-> permission/business logic
-> repository/data access
-> Cypher query
```

Follow only the relevant execution path.

Record file path + class + method/symbol for important links.

### 4. Verify against local Neo4j

Use the configured Neo4j MCP in READ-ONLY mode.

Start from the Cypher/nodes/relationships discovered from code.

Verify only relevant:

- node labels;
- relationship types;
- relationship direction;
- relevant properties;
- indexes/constraints if relevant;
- representative bounded topology;
- graph/test-data state used by the similar tests.

Do not dump large datasets. Prefer schema/aggregates and bounded queries.

### 5. Connect technical evidence to Gemma's business workflow

Read:

```text
.ai-local/current-story/business-workflow.md
```

Correlate:

```text
business workflow
<-> existing Cucumber
<-> step definitions
<-> discovered endpoint
<-> production code
<-> Cypher
<-> Neo4j nodes/relationships
```

Determine:

- which existing scenario is closest to the new highlighted flow;
- which existing Gherkin steps can be reused;
- what test-data/graph relationship differs;
- expected API behavior;
- whether a genuinely new step definition is required.

Prefer reuse of existing steps.

## ANTI-HALLUCINATION

Evidence hierarchy:

```text
1. Existing Cucumber tests
2. Actual repository code
3. Local read-only Neo4j
4. Gemma-extracted business workflow
```

If evidence is insufficient, write `UNKNOWN`. Do not guess.

## OUTPUT

Create:

```text
.ai-local/current-story/story-understanding.md
```

It must contain:

```markdown
# Story Understanding

## Business Subflow

## Closest Existing Cucumber Scenario

## Discovered API Endpoint

## Request/Test Setup

## Reusable Existing Gherkin Steps

## Step Definition Mapping

## Production Execution Path

## Relevant Cypher

## Relevant Neo4j Nodes

## Relevant Neo4j Relationships

## Difference Required For New Use Case

## Expected Result

## Proposed Cucumber Scenario

## New Step Definitions Required

## Unknowns

## Evidence
```

## MANDATORY STOP

Do not modify `TARGET_FEATURE` or any production/test source.

Present a concise summary to the user and ask:

```text
I have completed discovery and created
.ai-local/current-story/story-understanding.md.

Please review my understanding.

May I proceed with implementation using 03-devstral-implement.md?
```

Then STOP.

## SECURITY

Keep everything local. Web Search OFF. Neo4j READ ONLY. No public downloads or execution. Never expose secrets.
