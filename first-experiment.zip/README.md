# Permission API — First Local Multi-Model Experiment

You need **three prompts** for the main experiment and one optional reviewer.

## Order

### 1. Gemma session
Model: **Gemma 4 31B QAT**

Open:

`01-gemma-extract-workflow.md`

Fill only:
- baseline workflow file;
- new-use-case workflow file;
- highlight meaning.

Run it.

Expected output:

`.ai-local/current-story/business-workflow.md`

Review that file manually.

---

### 2. Devstral discovery session
Model: **Devstral Small 2**

Open:

`02-devstral-discover.md`

Fill only:
- 2–3 similar existing Cucumber feature paths;
- target feature path.

Run it.

Devstral must discover the endpoint, Java path, Cypher and Neo4j relationships itself.

Expected output:

`.ai-local/current-story/story-understanding.md`

**Review this file before allowing implementation.**

---

### 3. Devstral implementation
Model: **Devstral Small 2**

After you approve the discovery, run:

`03-devstral-implement.md`

Expected:
- Cucumber implementation;
- targeted test execution;
- `.ai-local/current-story/implementation-summary.md`.

---

### 4. Optional independent review
Model: **GPT-OSS 20B**

Run:

`04-gptoss-review.md`

Expected:

`.ai-local/current-story/review.md`

---

## What you provide

Only:

1. baseline workflow PPT/PDF/image;
2. new workflow PPT/PDF/image;
3. what the highlight means;
4. 2–3 similar existing `.feature` files;
5. target `.feature` path.

You do **not** provide endpoint, Java classes, step definitions, services, repositories, Cypher, nodes or relationships. Discovering those is part of the experiment.
