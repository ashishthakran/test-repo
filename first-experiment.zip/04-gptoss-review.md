# 04 — GPT-OSS: Independent Review (Optional)

## MODEL

Run this only if an independent second-model review is wanted.

Use **GPT-OSS 20B**.

Apply:

```text
@security-boundary
@adversarial-review
```

## INPUTS

Read:

```text
.ai-local/current-story/business-workflow.md
.ai-local/current-story/story-understanding.md
.ai-local/current-story/implementation-summary.md
```

Inspect the current Git diff and only the relevant surrounding repository code/tests.

## TASK

Independently review:

- whether the implemented Cucumber scenario matches the extracted business subflow;
- whether the discovered endpoint mapping is supported by code;
- whether existing Gherkin steps were reused correctly;
- whether unnecessary new steps were created;
- test-data correctness;
- Neo4j node/relationship assumptions;
- assertions;
- missing edge cases;
- accidental unrelated changes;
- hallucinated or unsupported behavior.

Do not trust Devstral's conclusions merely because they are documented.

Every BLOCKER/HIGH finding must contain repository/database evidence.

Do not modify files.

## OUTPUT

Create:

```text
.ai-local/current-story/review.md
```

Use:

```markdown
# Independent Review

## BLOCKER
## HIGH
## MEDIUM
## LOW
## INFORMATIONAL
## Verified Correct Decisions
## Unknowns
```

If there are BLOCKER/HIGH findings, tell the user to switch back to Devstral and address only evidence-backed findings.

## SECURITY

Keep everything local. Web Search OFF. Neo4j READ ONLY. No downloads or external transmission.
